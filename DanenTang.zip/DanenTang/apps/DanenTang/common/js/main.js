var busyIndicator = null;

function wlCommonInit(){
	/*
	 * Use of WL.Client.connect() API before any connectivity to a MobileFirst Server is required. 
	 * This API should be called only once, before any other WL.Client methods that communicate with the MobileFirst Server.
	 * Don't forget to specify and implement onSuccess and onFailure callback functions for WL.Client.connect(), e.g:
	 *    
	 *    WL.Client.connect({
	 *    		onSuccess: onConnectSuccess,
	 *    		onFailure: onConnectFailure
	 *    });
	 *     
	 */
	
	// Common initialization code goes here
	busyIndicator = new WL.BusyIndicator();
	loadStudents();
}

function loadStudents(){
	var invocationData = {
			adapter : 'adapterlist',
			procedure : 'getAdapterlists',
			parameters : []
		};
	
	WL.Client.invokeProcedure(invocationData,{
		onSuccess : loadStudentsSuccess,
		onFailure : loadStudentsFailure
	});
}

function loadStudentsSuccess(result){
	WL.Logger.debug("Feed retrieve success");
    WL.Logger.debug(JSON.stringify(result));

    if (result.responseJSON.resultSet.length >= 0) {
    	displayStudents(result.responseJSON.resultSet);      
    } 
}

function displayStudents(items){
	var content = "";
	for (var i = 0; i < items.length; i++) {
		var masv = items[i].masv;
		var tensv = items[i].tensv;
		var anh='<img  src="images/ic.png">';
		var lop = items[i].lop;
		content += anh + masv + " " + tensv +" "+ lop + "<br/>";
		
						
	}
	
	$('#wrraper').html(content);
}

function loadStudentsFailure(){
	WL.Logger.error("Feed retrieve failure");
	WL.SimpleDialog.show("Engadget Reader", "Service not available. Try again later.", 
			[{
				text : 'Reload',
				handler : WL.Client.reloadApp 
			},
			{
				text: 'Close',
				handler : function() {}
			}]
		);
}

function themoiuser(){
	
	var invocationData = {
	        adapter: 'adapterlist',
	        procedure: 'addAdapterlist',
	        parameters: [$('#ma').val(), $('#ten').val(),  $('#lop').val()]
	    };
	    WL.Client.invokeProcedure(invocationData, {onSuccess: themThanhCong, onFailure: themLoi});	
}

function themThanhCong() {
	alert("thanh cong");
}

function themLoi() {
	alert("that bai");
}